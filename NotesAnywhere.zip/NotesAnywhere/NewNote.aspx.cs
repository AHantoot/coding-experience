﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace NotesAnywhere
{
    public partial class NewNote : System.Web.UI.Page
    {
        SqlConnection con;
        SqlCommand cmd;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Titletxt.Text = "";
            Contenttxt.Text = "";
        }
        
        protected void Button1_Click(object sender, EventArgs e) //Add button to create new note in notebook
        {
            Guid newuserid = Guid.NewGuid();
            con = new SqlConnection("Data Source=notesforall.database.windows.net;Initial Catalog=NotesAnywhere;User ID=guest1;Password=Password123;MultipleActiveResultSets=True;Application Name=EntityFramework");
            con.Open();
            cmd = new SqlCommand("INSERT INTO Notes (NoteId,NotebookTitle,Username,NoteTitle,NoteContent) values (@noteid,@notebooktitle,@username,@notetitle,@notecontent)", con);
            cmd.Parameters.AddWithValue("@noteid", newuserid);
            cmd.Parameters.AddWithValue("@notebooktitle", DropDownList1.SelectedValue.ToString());
            cmd.Parameters.AddWithValue("@username", Session["New"].ToString());
            cmd.Parameters.AddWithValue("@notetitle", Titletxt.Text);
            cmd.Parameters.AddWithValue("@notecontent", Contenttxt.Text);
            cmd.ExecuteNonQuery();
            con.Close();
            Response.Redirect("NewNote.aspx");




        }
    }
}
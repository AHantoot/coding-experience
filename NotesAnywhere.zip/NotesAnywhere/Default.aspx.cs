﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data.Sql;
using System.Data.SqlClient;

namespace NotesAnywhere
{

    public partial class _Default : Page

    {



        SqlConnection con;
        SqlCommand cmd;



        protected void Add_Click(object sender, EventArgs e)
        {
            Guid newuserid = Guid.NewGuid();
            con = new SqlConnection("Data Source=notesforall.database.windows.net;Initial Catalog=NotesAnywhere;User ID=guest1;Password=Password123;MultipleActiveResultSets=True;Application Name=EntityFramework");
            con.Open();
            cmd = new SqlCommand("INSERT INTO QuickNote (QNoteId,Username,QNoteTitle,QNoteContent) values (@noteid,@username,@noteTitle,@notecontent)", con);
            cmd.Parameters.AddWithValue("@noteTitle", Titlebox.Text);
            cmd.Parameters.AddWithValue("@notecontent", Titlebox0.Text);
            cmd.Parameters.AddWithValue("@username", Session["New"].ToString());
            cmd.Parameters.AddWithValue("@noteid", newuserid);
            //   cmd.Parameters.AddWithValue("@nbtitle", "quicknote");
            cmd.ExecuteNonQuery();
            Titlebox.Text = "";
            Titlebox0.Text = "";
            Label1.Visible = true;
            con.Close();
            Response.Redirect("Default.aspx");
        }

        protected void logoutbttn_Click(object sender, EventArgs e)
        {
            Session["New"] = null;
            Response.Redirect("LogInPage.aspx");
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["New"] != null)
            {
                unamelbl.Text = $"welcome back {Session["new"]}";
            }
            else
            {
                Response.Redirect("LogInPage.aspx");
            }
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

            GridViewRow row = GridView1.SelectedRow;


            Titlebox0.Text = row.Cells[1].Text;
        }

        protected void Clear_Click(object sender, EventArgs e)
        {
            Titlebox.Text = "";
            Titlebox0.Text = "";

        }

        protected void Delete_Click(object sender, EventArgs e)
        {
            //con = new SqlConnection("Data Source=notesforall.database.windows.net;Initial Catalog=NotesAnywhere;User ID=guest1;Password=Password123;MultipleActiveResultSets=True;Application Name=EntityFramework");
            //con.Open();
            //cmd = new SqlCommand("DELETE FROM Notes (NoteId,Username,NoteTitle,NoteContent) values (@noteid,@username,@noteTitle,@notecontent)", con);
        }

        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            //GridViewRow row = GridView1.SelectedRow;


            //Titlebox0.Text = row.Cells[0].Text;

        }
    }
}
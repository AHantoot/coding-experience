﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace NotesAnywhere
{
    public partial class Notebook : System.Web.UI.Page
    {
        SqlConnection con;
        SqlCommand cmd;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Addbttn_Click(object sender, EventArgs e)
        {
            con = new SqlConnection("Data Source=notesforall.database.windows.net;Initial Catalog=NotesAnywhere;User ID=guest1;Password=Password123;MultipleActiveResultSets=True;Application Name=EntityFramework");
            con.Open();
            cmd = new SqlCommand("INSERT INTO Notebook (NotebookTitle,Username) values (@notetitle,@username)", con);
            cmd.Parameters.AddWithValue("@notetitle", NotebookTitleTxtbox.Text);
            cmd.Parameters.AddWithValue("@username", Session["New"].ToString());
            cmd.ExecuteNonQuery();
            NotebookTitleTxtbox.Text = "";
            con.Close();
            Response.Redirect("Notebook.aspx");
        }

        protected void GridView1_RowDeleted(object sender, GridViewDeletedEventArgs e)
        {

        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow gr = GridView1.SelectedRow;
            
            Session["Booktitle"] = gr.Cells[1].Text;
            NotebookTitleTxtbox.Text = Session["Booktitle"].ToString();
            Response.Redirect("Notebook.aspx");
        }

        protected void NoteTittletxt_TextChanged(object sender, EventArgs e)
        {

        }

        protected void GridView2_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow gr = GridView2.SelectedRow;
            NoteTittletxt0.Text = gr.Cells[1].Text;
            NoteTittletxt0.Text = gr.Cells[2].Text;
            Response.Redirect("Notebook.aspx");
        }
    }
}
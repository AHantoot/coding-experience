﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

namespace NotesAnywhere
{
    public partial class LoginPage : System.Web.UI.Page
    {
       
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                SqlConnection con = new SqlConnection(@"Data Source=notesforall.database.windows.net;Initial Catalog=NotesAnywhere;User ID=guest1;Password=Password123;MultipleActiveResultSets=True;Application Name=EntityFramework");
                con.Open();
                string checkuser = "select count(*) from Users where Username = '"+Usernametxt.Text+"'";
                SqlCommand com = new SqlCommand(checkuser, con);
                int temp = Convert.ToInt32(com.ExecuteScalar().ToString());
                if (temp == 1)
                {
                    Response.Write("User already Exists");
                }
                con.Close();
            }
        }

        protected void Loginbtn0_Click(object sender, EventArgs e) //register button click
        {
            //SqlConnection conn = new SqlConnection(@"Data Source=notesforall.database.windows.net;Initial Catalog='Notes for all';Persist Security Info=True;User ID=guest1;Password=Password123");
            
            
        }

        protected void Register_Click(object sender, EventArgs e)
        {

            //model.Username = Usernametxt.Text.Trim();
            //model.Password = Passwordtxt.Text.Trim();
            //model.Email = Emailtxt.Text.Trim();
            //model.Firstname = Firstnametxt.Text.Trim();
            //model.Lastname = Lastnametxt.Text.Trim();
            //using (NotesAnywhereEntities2 db = new NotesAnywhereEntities2())
            //{
            //    db.Users.Add(model);
            //    db.SaveChanges();
            //}
            //Response.Redirect("LogInPage.aspx");
            try
            {


                SqlConnection con = new SqlConnection(@"Data Source=notesforall.database.windows.net;Initial Catalog=NotesAnywhere;User ID=guest1;Password=Password123");
                con.Open();                                                                 //defining name here
                string insert = "insert into Users (Firstname,Lastname,Username,Password,Email) values (@fname, @lname, @username, @password, @email)";
                SqlCommand com = new SqlCommand(insert, con);
                com.Parameters.AddWithValue("@username", Usernametxt.Text);
                com.Parameters.AddWithValue("@password", Passwordtxt.Text);
                com.Parameters.AddWithValue("@email", Emailtxt.Text);
                com.Parameters.AddWithValue("@fname", Firstnametxt.Text);
                com.Parameters.AddWithValue("@lname", Lastnametxt.Text);

                com.ExecuteNonQuery();
                Response.Redirect("LogInPage.aspx");
                Response.Write("Acount registration complete!");
                con.Close();
            }
            catch (Exception ex)
            {
                Response.Write("Error:" + ex.ToString());
            }

        }

        protected void Usernametxt_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
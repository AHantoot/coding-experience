﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

namespace NotesAnywhere
{
    public partial class LogInPage : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void Login_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=notesforall.database.windows.net;Initial Catalog=NotesAnywhere;User ID=guest1;Password=Password123");
            con.Open();
            string checkuser = "select count(*) from Users where Username = '" + uname.Text + "'";
            SqlCommand com = new SqlCommand(checkuser, con);
            int temp = Convert.ToInt32(com.ExecuteScalar().ToString());
            con.Close();
            if (temp == 1)
            {
                con.Open();
                string checkpasswordquery = "select Password from Users where Username = '" + uname.Text + "'";
                SqlCommand passCom = new SqlCommand(checkpasswordquery, con);
                string passwordstr = passCom.ExecuteScalar().ToString();

                if(passwordstr == password.Text)
                {
                    Session["New"] = password.Text;
                    Response.Write("password is correct");
                    con.Close();
                    Response.Redirect("Default.aspx");
                }
                else
                {
                    Response.Write("Password is not correct");
                }
            }
            else
            {
                Response.Write("Username is not correct");
            }
            con.Close();
        }

        protected void Register_Click(object sender, EventArgs e)
        {
            Response.Redirect("LogInPage.aspx");
        }
    }
}